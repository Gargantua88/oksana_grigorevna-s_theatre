require 'test_helper'

class DateInferTest < ActionDispatch::IntegrationTest

  setup do
    @date_infer = DateInfer.new
  end

  test 'hours minutes seconds' do
    assert_valid_dates({ 
      '%H:%M' => ['18:48', '20:20', '02:34'],
      '%l:%M %p' => '6:48 PM',
      '%H:%M:%S %z' => '18:48:39 +0000',
      '%l:%M:%S%z' => '6:48:39+0000',
      '%I:%M:%S %p' => '06:48:39 PM',
      '%H:%M:%S' => '18:48:39',
      '%H:%M:%S%p' => '18:48:39PM'
    })
  end

  test 'day month year' do
    assert_valid_dates({ 
      '%A, %b %d' => 'Friday, Feb 02',
      '%d/%m/%Y' => '02/02/2018',
      '%d-%-m-%y' => '02-2-18',
      '%b %e,' => 'Feb 2,',
      '%B %Y' => 'February 2018',
      '%b %d, %Y' => 'Feb 02, 2018',
      '%a, %e %b %Y' => 'Fri, 2 Feb 2018',
      '%Y-%d-%mT' => '2018-02-02T',
      '%d.%m.%y' => '02.02.18',
      '%A, %d %b %Y' => 'Friday, 02 Feb 2018',
      '%d %b %Y' => ['20 Dec 2017', '02 Dec 2017', '02 Feb 1017'],
      '%e %b %Y' => '2 Feb 2018',
      '%d %m %Y' => '02 11 2017',
      '%d, %b, %y' => '20, Dec, 18',
      '%d, %b, %Y' => '20, Dec, 2018',
      '%d, %m, %Y' => '20, 02, 2018',
      #'%d-%b-%Y' => '15-Dec-2018' ??????? not worked for now(python lib issue)
    })
  end

  test 'full date' do
    assert_valid_dates({ 
      '%d-%-m-%y %H:%M' => '02-2-18 18:48',
      '%b %e, %l:%M %p' => 'Feb 2, 6:48 PM',
      '%a, %e %b %Y %H:%M:%S %z' => 'Fri, 2 Feb 2018 18:48:39 +0000',
      '%Y-%d-%mT%l:%M:%S%z' => '2018-02-02T6:48:39+0000',
      '%e %b %Y %H:%M:%S%p' => '2 Feb 2018 18:48:39PM',
      '%A, %d %b %Y %l:%M %P' => 'Friday, 02 Feb 2018 6:48 pm',
      '%d %b %Y %H:%M' => '02 Dec 2017 20:20',
      '%d %m %Y %H:%M' => '02 11 2017 10:00',
      '%d, %b, %Y %H:%M:%S' => '20, Dec, 2018 18:48:39',
      '%d, %b, %Y %H:%M:%S %Z' => ['20, Dec, 2018 18:48:39 MSK', '20, Dec, 2018 18:48:39 AST'],
      '%d %B %Y, %k:%M' => '17 December 2016, 1:44'
    })
  end


  def assert_valid_dates(formats)
    formats.each do |valid_format, data|
      if data.is_a? Array
        data.each do |date| 
          asset_valid_date(date, valid_format) 
        end
      else
        date = data
        asset_valid_date(date, valid_format)
      end
    end
  end

  def asset_valid_date(date, valid_format)
    @date_infer.set_date(date).run

    assert_equal(valid_format, @date_infer.result, "date: #{date}")
  end

end