function FormatHistory(name, max) 
{
  return {
    key: name,
    maxItems: max,
    hash: {},
    items: [],
    isValid: function (item) {
      return (item && item.date && item.format);
    },
    hasItem(item){
      if (this.hash[item.format]) return true;

      return false;
    },
    add: function (item) {
      if (!this.isValid(item)) return false;

      if (this.hasItem(item)) {
        this.remove(item);
      }

      var history = fromStorage(this.key);

      if (history && history instanceof Array) {
        history.unshift(item);

        if (history.length > this.maxItems) {
          history = history.splice(0, this.maxItems);
        }
      } else {
        history = [item];
      }

      this.hash[item.format] = true;
      this.items = history;
      toStorage(this.key, history);

      return true;  
    },
    remove: function (item) {
      if (!this.isValid(item) || !this.hasItem(item) || item.fixed) return false;

      this.hash[item.format] = undefined;

      for (var i = 0; i < this.items.length; i++) {
        if (this.items[i].format === item.format) {
          this.items.splice(i, 1);
          break;
        }
      }

      toStorage(this.key, this.items);

      return true;
    },
    load: function () {
      this.items = fromStorage(this.key);

      if (!this.items || !(this.items instanceof Array)) {
        this.items = [];
      } else {
        for (var i = 0; i < this.items.length; i++) {
          this.hash[this.items[i].format] = true;
        }
      }

      return this.items;
    }
  }
}