function FormatItems()
{
  return {
    items: {},
    setFormat: function (format) {
      this.items = {};

      if (!format) return;

      var matches = format.match(/(%-?\w)/ig);

      if (matches.length) {
        for (var i = 0; i < matches.length; i++) {
          this.items[matches[i]] = true;
        }
      }
    }
  };
}