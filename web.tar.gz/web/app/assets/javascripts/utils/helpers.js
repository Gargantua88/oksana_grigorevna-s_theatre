function toStorage(key, obj) {
  localStorage.setItem(key, JSON.stringify(obj));
}

function fromStorage(key) {
  var result = localStorage.getItem(key);

  if (result)
    result = JSON.parse(result);

  return result;
}


function setQueryParams(params) {
  var url = window.location.protocol + "//" + window.location.host + window.location.pathname;

  if (params) {
    var paramsString = '?';

    for (var key in params) {
      if (params.hasOwnProperty(key)) {
        if (paramsString == '?')
          paramsString += key + '=' + params[key]
        else
          paramsString += '&' + key + '=' + params[key]
      }
    }

    url += paramsString;
  }

  window.history.pushState({ path: url },'', url);
}