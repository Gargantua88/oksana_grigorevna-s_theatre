function Errors() 
{
  return {
    any: false,
    items: {},
    set: function (items) {
      if (items instanceof String) {
        items = JSON.parse(items);
      }

      this.items = items;

      if (this.size() > 0)
        this.any = true;
      else
        this.any = false;
    },
    size: function() {
      var size = 0, key;

      for (key in this.items) {
          if (this.items.hasOwnProperty(key)) size++;
      }

      return size;
    }
  };
}