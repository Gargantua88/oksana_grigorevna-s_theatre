var home = new Vue({
  el: '#home',
  data: {
    path: '/api/date/infer',
    datetime: {
      value: '',
      format: '',
      formatItems: FormatItems(),
      errors: Errors()
    },
    presets: [
      { date: '9 Feb 2018 19:31:44',     format: '%e %b %Y %H:%M:%S' },
      { date: '17 December 2016, 14:44', format: '%d %B %Y, %H:%M' },
      { date: '13:46:50',                format: '%H:%M:%S' },
      { date: '14 hours 52 minutes',     format: '%H hours %M minutes' },
    ],
    favorite: FormatHistory('favorite', 20),
    history: FormatHistory('history', 8),
    formatReference: {
      items: reference.items,
      langsLinks: {}
    }
  },
  methods: {
    onSubmit: function (event) {
      if (!this.datetime.value) {
        if (this.favorite.items.length) {
          this.datetime.value = this.favorite.items[0].date;
          this.datetime.format = this.favorite.items[0].format;
        } else {
          this.datetime.value = this.presets[0].date;
          this.datetime.format = this.presets[0].format;
        }

        return;
      }

      let self = this;
      self.datetime.errors.set({});
      setQueryParams({ date: this.datetime.value });
      
      axios.post(this.path, {
        date: this.datetime.value
      })
      .then(function (response) {
        self.datetime.format = response.data.format;
        self.datetime.formatItems.setFormat(self.datetime.format);

        if (Object.keys(self.datetime.formatItems.items).length)
          self.history.add({ date: self.datetime.value, format: self.datetime.format });
        
      })
      .catch(function (error) {
        if (error.response && error.response.data)
          self.datetime.errors.set(error.response.data);
      });
    },
    selectFromHistory: function (item) {
      if (!item || !item.date || !item.format) return;

      this.datetime.value = item.date;
      this.datetime.format = item.format;
      this.datetime.formatItems.setFormat(this.datetime.format);

      setQueryParams({ date: this.datetime.value });
    },
    opacity: function(index) {
      if (index == 0) return '';
      else if (index == 1) return 'o-90';
      else if (index == 2 || index == 3) return 'o-70';
      else if (index == 4 || index == 5) return 'o-60';
      else if (index == 5 || index == 6) return 'o-50';
      else if (index == 7 || index == 8) return 'o-30';
      else if (index == 9 || index == 10) return 'o-20';
      else return 'o-10';
    },
    initDatetime: function () {
      if (
          document.__init__ && document.__init__.datetime &&
          document.__init__.datetime.value && document.__init__.datetime.format
      ) {
        this.datetime.value  = document.__init__.datetime.value;
        this.datetime.format = document.__init__.datetime.format;
      }

      if (this.datetime.format)
        this.datetime.formatItems.setFormat(this.datetime.format);
    }
  },
  mounted: function () {
    this.history.load();
    this.favorite.load();

    this.initDatetime();

    new Clipboard('#copy');
  }
});
