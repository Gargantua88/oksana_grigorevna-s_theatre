window.reference = {
    items: [
        { symb: '', desc: 'Day of the month', sampl: '', header: true },
        { symb: '%d', desc: 'zero-padded', sampl: '01..31' },
        { symb: '%e', desc: 'blank-padded', sampl: '1..31' },

        { symb: '', desc: 'Month number', sampl: '', header: true },
        { symb: '%m', desc: 'zero-padded', sampl: '01..12' },
        { symb: '%-m', desc: 'no-padded', sampl: '1..12' },

        { symb: '', desc: 'Month name', sampl: '', header: true },
        { symb: '%B', desc: 'full', sampl: 'January' },
        { symb: '%b', desc: 'abbreviated', sampl: 'Jan' },

        { symb: '', desc: 'Year', sampl: '', header: true },
        { symb: '%Y', desc: 'with century', sampl: '0000, 1995' },
        { symb: '%y', desc: 'year % 100', sampl: '00..99' },
        { symb: '%C', desc: 'century', sampl: 'as 20 in 2009' },
        { symb: '%j', desc: 'day of the year', sampl: '001..366' },

        { symb: '', desc: 'Weekday', sampl: '', header: true },
        { symb: '%A', desc: 'full name', sampl: 'Sunday' },
        { symb: '%a', desc: 'abbreviated name', sampl: 'Sun' },
        // { symb: '%u', desc: 'number', sampl: 'Monday is 1, 1..7' },
        // { symb: '%w', desc: 'number', sampl: 'Sunday is 0, 0..6' },

        { symb: '', desc: 'Hour of the day', sampl: '', header: true },
        { symb: '%H', desc: '24-hour clock, zero-padded', sampl: '00..23' },
        { symb: '%k', desc: '24-hour clock, blank-padded', sampl: '0..23' },
        { symb: '%I', desc: '12-hour clock, zero-padded', sampl: '00..12' },
        { symb: '%l', desc: '12-hour clock, blank-padded', sampl: '1..12' },

        { symb: '', desc: 'Minutes and seconds', sampl: '', header: true },
        { symb: '%M', desc: 'Minute of the hour', sampl: '00..59' },
        { symb: '%S', desc: 'Second of the minute', sampl: '00..60' },

        { symb: '', desc: 'Meridian indicator', sampl: '', header: true },
        { symb: '%P', desc: 'lowercase', sampl: 'am or pm' },
        { symb: '%p', desc: 'uppercase', sampl: 'AM or PM' },

        { symb: '', desc: 'Time zone', sampl: '', header: true },
        { symb: '%z', desc: 'offset from UTC', sampl: '+0900' },
        { symb: '%Z', desc: 'abbreviated', sampl: 'UTC+9' },
    ]
};