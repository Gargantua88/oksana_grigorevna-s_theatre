class HomeController < ApplicationController

  def index
    set_datetime!

    # @ids = { "blue" => "#408BC9", "red" => "#FF4136", "green" => "#19A974" }
    @ids = { "blue" => "#76C4E2", "red" => "#FF725C", "green" => "#9EEBCF" } #light

    @base_color = ["green", "red", "blue"].sample
    # @base_color = "green"

    @color_id = @ids[@base_color]

    @tone, @color    = "light-#{@base_color}", "black-70"
    @accent          = "white"
    @bg              = "bg-white"

    @ref_highlighted = "bg-#{@color} #{@tone}"

    @title_h1        = "f1 ma0 ib black-70"

    @ref_header      = "f5 b #{@accent}"

    @ref_base        = "ph3"
    @ref_sym         = "dib border-box tr f5 b ref-sym"
    @ref_desc        = "dib border-box tl helvetica"
    @ref_body        = "pb2 pt1 ph3  bg-#{@tone} #{@color} br2 scratches"

    @infer_body      = "w-100 pa4 ba b--black-10 br2"
    @infer_label     = "f6 black-90"

    @infer_preset    = "pv1 ph2 bg-#{@tone} br3 #{@color} bg-animate hover-bg-#{@base_color} hover-#{@accent}"

    @footer_block     = "w-15 ph2 pv0 mr2 mh0 b--#{@base_color} hover-#{@base_color} br2 f6"

    @footer_link      = "dib br2 pv1 pl1 pr2 link b bg-animate hover-bg-light-#{@base_color} black-80"
  end

  protected

    def set_datetime!
      @datetime = {}

      if params[:date] && (form = DateForm.new(date: params[:date])).valid?
        @datetime[:value] = params[:date]
        @datetime[:format] = DateInfer.new.set_date(params[:date]).run.result
      end

      @datetime
    end

end
