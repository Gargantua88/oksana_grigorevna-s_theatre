class Api::DateController < ActionController::API
  include Api::Response
  include Api::ExceptionHandler

  def infer
    form = DateForm.new(date_params)

    if form.valid?
      date_infer = DateInfer.new.set_date(params[:date]).run
      json_response({ format:  date_infer.result })
    else
      json_response(form.errors.to_h, :unprocessable_entity)
    end
  end

  protected
    def date_params
      params.permit(:date)
    end

end
