class FormatFixer

  def self.post(value, params = {})
    if params[:original_date]
      changes = false
      original = params[:original_date]

      format_values = value.scan(/%-?[a-zA-Z]|[0-9]+|[a-zA-Z]/i)
      format_indexes = indexes(value, /%-?[a-zA-Z]|[0-9]+|[^dmebycajuwhkilpmsz\d\W]+|^%[a-z]/i)
      original_values = original.scan(/[0-9]+|[a-zA-Z]+/i)

      if format_values && original_values && format_values.length == original_values.length
        format_values.each_index do |i|
          if format_values[i] == '%d' && original_values[i].match(/\A[1-9]\z/)
            value[format_indexes[i] + 1] = 'e' if format_indexes[i] && format_indexes[i] + 1
          elsif format_values[i] == '%m' && original_values[i].match(/\A[1-9]\z/)
            value[format_indexes[i] + 1] = '-m' if format_indexes[i] && format_indexes[i] + 1
          elsif format_values[i] == '%H' 
            values = original_values[i..-1].map { |i| i.downcase }

            if original_values[i].match(/\A0[1-9]|1[0-2]\z/) && values.include?('pm') || values.include?('am')
              value[format_indexes[i] + 1] = 'I' if format_indexes[i] && format_indexes[i] + 1
            elsif original_values[i].match(/\A[1-9]\z/)
              if values.include?('pm') || values.include?('am')
                value[format_indexes[i] + 1] = 'l' if format_indexes[i] && format_indexes[i] + 1
              else
                value[format_indexes[i] + 1] = 'k' if format_indexes[i] && format_indexes[i] + 1
              end
            end
          elsif format_values[i] == '%I' && original_values[i].match(/\A[1-9]\z/)
            value[format_indexes[i] + 1] = 'l' if format_indexes[i] && format_indexes[i] + 1
          elsif format_values[i] == '%p' && (original_values[i] == 'am' || original_values[i] == 'pm')
            value[format_indexes[i] + 1] = 'P' if format_indexes[i] && format_indexes[i] + 1
          end
        end
      end
    end

    value
  end


  def self.indexes(string, regexp)
    start, result = -1, []

    while start = (string.index regexp, start + 1)
      result << start
    end

    result
  end

end