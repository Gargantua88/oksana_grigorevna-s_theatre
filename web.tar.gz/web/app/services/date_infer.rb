class DateInfer

  attr_reader :date, :result, :modifier

  def initialize(pre_processors = [DateTransform], post_processors = [TzAbbr, FormatFixer])
    @date = nil
    @result = nil
    @pre = pre_processors
    @post = post_processors
  end

  def set_date(date)
    @date = date

    self
  end

  def set_modifiers(modifiers)
    @modifiers = modifiers

    self
  end

  def run
    cmd = %(#{path_to_exec_file} "#{args}")

    @result = apply_post_processors((`#{cmd}`).strip, @date)

    self
  end

  private

    def path_to_exec_file
      "python #{Rails.root.join('lib', 'date_infer.py')}"
    end

    def args
      date = @date.gsub("\"", %q(\\\"))
      date = apply_pre_processors(date, @date)

      date
    end

    def apply_pre_processors(date, original_date)
      if @pre && @pre.length > 0
        @pre.each do |modifier|
          date = modifier.pre(date, original_date: original_date)
        end
      end

      date
    end

    def apply_post_processors(date_format, original_date)
      if @post && @post.length > 0
        @post.each do |modifier|
          date_format = modifier.post(date_format, original_date: original_date)
        end
      end

      date_format
    end

end