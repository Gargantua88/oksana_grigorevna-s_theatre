class DateTransform

  @@rules = [
    {
      desc: '"+0000" => "+0900"',
      regexp: /(\A|[\s\;\/\#]+|.)([+-][0-9]{3}0)/,
      replace: '\1+0900'
    },
    {
      desc: '"10:00" => "23:59"',
      regexp: /(\A|[\s\.\-\:\;\/\#]+)([0-1][0-9]|2[0-3]|[0-9]):([0-5][0-9])([\s\,\.\-\;\/\#]+|\z)/i,
      replace: '\123:59\4'
    },
    {
      desc: '"32-Dec" => "01-Dec"',
      regexp: /(\A|[\s\,\.\-\;\/\#]+)(3[0-1]|2[0-9]|1[0-9]|0[1-9]|[1-9])([\s\,\.\-\;\/\#]+)(12|11|0[1-9]|[1-9]|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sept|Oct|Nov|Dec|January|February|March|April|May|June|July|August|September|October|November|December)([\s\,\.\-\;\/\#]+|\z)/i,
      replace: '\101\3\4\5'
    },
    {
      desc: '"02-02-18" => "02-02-99"',
      regexp: /(\A|[\s\,\.\-\;\/\#]+)(3[0-1]|2[0-9]|1[0-9]|0[1-9]|[1-9])([\s\,\.\-\;\/\#]+)(12|11|0[1-9]|[1-9]|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sept|Oct|Nov|Dec|January|February|March|April|May|June|July|August|September|October|November|December)([\s\,\.\-\;\/\#]+)([0-9]{2})([\s\,\.\-\;\/\#]+|\z)/i,
      replace: '\101\3\4\599\7'
    },
    {
      desc: '"32-Dec-2018" => "01-Dec-2018"',
      regexp: /(\A|[\s\,\.\-\;\/\#]+)(3[0-1]|2[0-9]|1[0-9]|0[1-9]|[1-9])([\s\,\.\-\;\/\#]+)(12|11|0[1-9]|[1-9]|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sept|Oct|Nov|Dec|January|February|March|April|May|June|July|August|September|October|November|December)([\s\,\.\-\;\/\#]+)([0-9]{4})([\s\,\.\-\;\/\#]+|\z)/i,
      replace: '\101\3\4\5\6\7'
    },
    {
      desc: '"02 11 2017 10:00", "02 Dec 2017 20:20" => "02 Dec 2017 23:59"',
      regexp: /(\A|[\.\,\-\:\;\/\#]|\s+)(31|30|29|28|27|26|25|24|23|22|21|20|19|18|17|16|15|14|13|12|11|10|0[1-9])([\s\.\,\-\:\;\/\#]{1})(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sept|Oct|Nov|Dec|January|February|March|April|May|June|July|August|September|October|November|December|0[1-9]|1[1-2])([\s\.\-\:\;\/\#]{1})([0-9]{4})([\s\.\-\:\;\/\#]+)([0-1][0-9]|2[0-3]|):([0-5][0-9])/i,
      replace: '\101\3\4\5\6\723:59'
    },
  ]

  def self.pre(value, params = {})
    @@rules.each do |rule|
      value = value.gsub(rule[:regexp], rule[:replace])
    end

    value
  end


end