class DateForm
  include ActiveModel::Model

  attr_accessor(
    :date
  )

  validates :date, presence: true, length: { minimum: 1, maximum: 60 }

  
end