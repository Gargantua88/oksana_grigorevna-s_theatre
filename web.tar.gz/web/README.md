# strftime


## Dependencies

- python 2.7

- python [dateinfer lib](https://github.com/jeffreystarr/dateinfer)


## Installation

- `bundle install`

- `pip install dateinfer`


