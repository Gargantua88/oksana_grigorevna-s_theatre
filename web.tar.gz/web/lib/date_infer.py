import sys, dateinfer

def run():
    args = sys.argv[1:]

    if len(args):
      return dateinfer.infer(args)
    else:
      return ''


if __name__ == "__main__":
  print run()