Rails.application.routes.draw do
  resource :home, only: :index

  root "home#index"

  namespace :api do
    post 'date/infer', to: 'date#infer'
  end
end
